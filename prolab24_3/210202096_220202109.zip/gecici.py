import json
import networkx as nx
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import tkinter as tk


class HashTablosu:
    def __init__(self, boyut):
        self.boyut = boyut
        self.tablo = [None] * boyut

    def hash_fonksiyonu(self, anahtar):
       
        return sum(ord(char) for char in anahtar) % self.boyut

    def ekle(self, anahtar, deger):
        indeks = self.hash_fonksiyonu(anahtar)
        if self.tablo[indeks] is None:
            self.tablo[indeks] = []
        self.tablo[indeks].append((anahtar, deger))

    
    def getir(self, anahtar):
        indeks = self.hash_fonksiyonu(anahtar)
        if self.tablo[indeks] is not None:
            for tup in self.tablo[indeks]:
                if tup[0] == anahtar:
                    return tup[1]
        raise KeyError(f"{anahtar} bulunamadi.") 
  
    

def kullanici_olustur(username, name, followers_count, following_count, language, region, tweets, following, followers):
    return {
        "username": username,
        "name": name,
        "followers_count": followers_count,
        "following_count": following_count,
        "language": language,
        "region": region,
        "tweets": tweets,
        "following": following,
        "followers": followers,
        "edges": []
    }

class KullaniciGrafi:
    def __init__(self):
        self.graf = nx.Graph()

    def edge_ekle(self, kullanici1, kullanici2):
        self.graf.add_edge(kullanici1, kullanici2)

    def graf_olustur(self, kullanici_nesneleri):
        for kullanici in kullanici_nesneleri:
            username = kullanici["username"]
            followers = kullanici["followers"]
            for follower in followers:
                self.edge_ekle(username, follower)
                self.graf.nodes[username]["kullanici_nesnesi"] = kullanici
              

    def graf_cizdir(self):

        pos = nx.spring_layout(self.graf)
        nx.draw(self.graf, pos, with_labels=True, font_weight='normal', font_size=6, node_color='skyblue',
                edge_color="gray", node_size=200)

        # Show the plot using Matplotlib
        plt.show()
       
        


def main():
    # JSON verisini dosyadan okuma
    with open("twitter_data.json", "r", encoding="utf-8") as dosya:
        kullanici_verileri = json.load(dosya)

    # Kullanıcı nesnelerini oluştur
    kullanici_nesneleri = []
    for kullanici in kullanici_verileri:
        kullanici_nesnesi = kullanici_olustur(
            kullanici["username"],
            kullanici["name"],
            kullanici["followers_count"],
            kullanici["following_count"],
            kullanici["language"],
            kullanici["region"],
            kullanici["tweets"],
            kullanici["following"],
            kullanici["followers"]
        )
        kullanici_nesneleri.append(kullanici_nesnesi)

    # Hash tablosu oluştur
    hash_tablosu = HashTablosu(len(kullanici_nesneleri))

    # Kullanıcıları hash tablosuna ekle
    for kullanici_nesnesi in kullanici_nesneleri:
        username = kullanici_nesnesi.get("username", "")
        hash_tablosu.ekle(username, kullanici_nesnesi)
    
    kullanici_grafi = KullaniciGrafi()
    kullanici_grafi.graf_olustur(kullanici_nesneleri)

    # Grafı çizdir
    kullanici_grafi.graf_cizdir()

if __name__ == "__main__":
    main()